"""
PAMI

A PAttern MIning python library.
"""

__version__ = "0.9.2"
__author__ = 'RAGE Uday Kiran'
__credits__ = 'The University of Aizu'
# **[Home](../index.html) | [Exercises](../exercises.html) | [Real-world Examples](../examples.html)**

# Real-world examples
 
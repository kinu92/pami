# **[Home](index.html) | [Exercises](exercises.html) | [Real-world Examples](examples.html)**  

# Topics

1. [Frequent pattern mining](./exercises/frequentPatternMining.html)